ALTER TABLE wcf1_user_tracker ADD wlgalAlbum TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE wcf1_user_tracker ADD wlgalImage TINYINT(1) NOT NULL DEFAULT 1;
