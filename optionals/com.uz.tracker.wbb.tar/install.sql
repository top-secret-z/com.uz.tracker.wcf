ALTER TABLE wcf1_user_tracker ADD wlwbbPost TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE wcf1_user_tracker ADD wlwbbThread TINYINT(1) NOT NULL DEFAULT 1;
