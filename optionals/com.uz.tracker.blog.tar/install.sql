ALTER TABLE wcf1_user_tracker ADD wlbloBlog TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE wcf1_user_tracker ADD wlbloEntry TINYINT(1) NOT NULL DEFAULT 1;

