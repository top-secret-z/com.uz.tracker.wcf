INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('calendar\\page\\CalendarFeedPage', 'calendarFeed', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('calendar\\page\\EventPage', 'event', 1);
