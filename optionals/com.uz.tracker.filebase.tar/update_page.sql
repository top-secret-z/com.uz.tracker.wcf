INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('filebase\\page\\FilePage', 'file', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('filebase\\page\\CategoryFileListPage', 'categoryFileList', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('filebase\\page\\CategoryFileListFeedPage', 'rssFeedCategoryFile', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('filebase\\page\\DownloadPage', 'download', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('filebase\\page\\FileListFeedPage', 'rssFeedFile', 1);
