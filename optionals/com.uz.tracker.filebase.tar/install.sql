ALTER TABLE wcf1_user_tracker ADD wlfilFile TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE wcf1_user_tracker ADD wlfilFileDownload TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE wcf1_user_tracker ADD wlfilFilePurchase TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE wcf1_user_tracker ADD wlfilFileVersion TINYINT(1) NOT NULL DEFAULT 1;
