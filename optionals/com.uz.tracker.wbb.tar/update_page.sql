INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('wbb\\page\\BoardPage', 'board', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('wbb\\page\\ThreadPage', 'thread', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('wbb\\page\\BoardFeedPage', 'rssFeedBoard', 1);
