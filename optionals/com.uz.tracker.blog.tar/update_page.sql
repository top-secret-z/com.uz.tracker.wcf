INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('blog\\page\\EntryPage', 'blogEntry', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('blog\\page\\BlogFeedPage', 'blogFeed', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('blog\\page\\CategoryEntryListPage', 'blogCategoryEntryList', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('blog\\page\\BlogEntryListPage', 'blogEntryList', 1);
