INSERT INTO wcf1_user_tracker_page (class, page, isPublic) VALUES ('gallery\\page\\AlbumPage', 'album', 1);
INSERT INTO wcf1_user_tracker_page (class, page, isPublic) VALUES ('gallery\\page\\ImagePage', 'image', 1);
INSERT INTO wcf1_user_tracker_page (class, page, isPublic) VALUES ('gallery\\page\\UserAlbumListPage', 'userAlbumList', 1);
INSERT INTO wcf1_user_tracker_page (class, page, isPublic) VALUES ('gallery\\page\\UserImageListPage', 'userImageList', 1);
INSERT INTO wcf1_user_tracker_page (class, page, isPublic) VALUES ('gallery\\page\\ImageListFeedPage', 'galleryFeed', 1);
INSERT INTO wcf1_user_tracker_page (class, page, isPublic) VALUES ('gallery\\page\\UserVideoListPage', 'userVideoList', 1);
